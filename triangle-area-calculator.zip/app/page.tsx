"use client"

import TriangleAreaCalculator from "../triangle-area-calculator"

export default function SyntheticV0PageForDeployment() {
  return <TriangleAreaCalculator />
}